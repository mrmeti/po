"""
VideoPlayerBot, Telegram Video Chat Bot
Copyright (c) 2021  Asm Safone <https://github.com/AsmSafone>

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU Affero General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU Affero General Public License for more details.

You should have received a copy of the GNU Affero General Public License
along with this program.  If not, see <https://www.gnu.org/licenses/>
"""

import os
from os import getenv
from dotenv import load_dotenv

load_dotenv()

admins = {}
OLD_PMS = {}
AUDIO_CALL = {}
VIDEO_CALL = {}
API_ID = int(getenv("API_ID", "7273371"))
API_HASH = getenv("API_HASH", "553337e711993d5be5dd95b61781eb4b")
BOT_TOKEN = getenv("BOT_TOKEN", "5063829317:AAHSDWobrsJmv_GZTaMx-hLu0sb55eHWD2U")
SESSION_STRING = getenv("SESSION_STRING", "BADGI0DSZUvSO6nFgVVh9GLcdWjppgml0xaTXZk9uph35bSRodEcADJaqs0I9rKD77bRVhgAW_USUWZ7734G7ZeD0oWFhn8v0dU3Xk6fq48l-HEgTngT4lGAw0OLid3iapQj8TnZbF5qf1tQc4lQbJ_N79hUkSA0lTUvC2na7sc1twSoVRyPTlohKX9kST4a_zhlR2Oqi_zKKGieLSwCF2bzsQRc0GGLZV8vu0PMUErSlEAobjzJK1GBfvpDgqn9D6ch3iPMRPp8A9WB6D7nL8CrJssVbZX6Xby3Ct_GUaSwMV4-koXZs82hOz-aTKToieQRap9-oPPwXP0fjTNgopXIAAAAAEiqt5gA")
SUPPORT_GROUP = getenv("SUPPORT_GROUP", "Metiwz")
UPDATES_CHANNEL = getenv("UPDATES_CHANNEL", "Metiwz_Team")
ASSISTANT_NAME = getenv("ASSISTANT_NAME", "MetiwzPlayer")
SUDO_USERS = list(map(int, getenv("SUDO_USERS" , "1900060993").split()))
REPLY_MESSAGE = getenv("REPLY_MESSAGE", "")
if not REPLY_MESSAGE:
    REPLY_MESSAGE = None
else:
    REPLY_MESSAGE = REPLY_MESSAGE
